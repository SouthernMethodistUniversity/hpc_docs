#!/bin/bash

. /opt/modules/3.1.6.5/init/bash

module load acml

./configure CXX=CC CC=cc F77=ftn MPICXX=CC FLIBS=-pgf77libs --prefix=${HOME}/local/franklin --with-blas="-L${ACML_DIR}/pgi64/lib -lacml -lacml_mv" --disable-shared
