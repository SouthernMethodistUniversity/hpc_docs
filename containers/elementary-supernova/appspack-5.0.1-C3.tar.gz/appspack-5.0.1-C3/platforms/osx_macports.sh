#!/bin/sh

./configure CXX=g++-mp-4.4 CC=gcc-mp-4.4 F77=gfortran-mp-4.4 --prefix=$HOME/local

