#!/bin/sh

. /usr/common/nsg/opt/Modules/default/init/sh
. /project/projectdirs/cmb/modules/carver/cmbenv.sh

cmbenv gnu

module load cmb
module unload idl

LAPACK="-L/usr/common/usg/mkl/10.2.2.025/lib/em64t -lmkl_solver_lp64 -lmkl_lapack95_lp64 -lmkl_blas95_lp64 -lmkl_intel_lp64 -lmkl_gnu_thread -lmkl_core -fop
enmp -lpthread"

./configure CC=gcc CXX=g++ F77=gfortran --prefix=${HOME}/local/carver --with-blas="${LAPACK}"

